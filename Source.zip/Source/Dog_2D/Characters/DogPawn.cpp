// Fill out your copyright notice in the Description page of Project Settings.


#include "Characters/DogPawn.h"

#include "Kismet/GameplayStatics.h"
#include "Interactive/InteractiveBox.h"
#include "Interactive/ItemBone.h"
#include "Interactive/HouseAlarmActor.h"



// Sets default values
ADogPawn::ADogPawn()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	bIsInteracting = false;
	bIsPushing = false;
	bIsPulling = false;

	bIsScared = false;

	StealthCover = nullptr;
	bIsInCover = false;
}

void ADogPawn::Move(float Value)
{

	ABaseDogPawn::Move(Value);

	

	/*if (bIsInteracting)
	{
		VelocityX = Value * MoveSpeed;

		SetMoveDirection(Value);

		FVector DeltaLocation(VelocityX * GetWorld()->GetDeltaSeconds(), 0.f, 0.f);
		AddActorWorldOffset(DeltaLocation, true);
	}
	else
	{
		ABaseDogPawn::Move(Value);
	}*/	
}
void ADogPawn::UpdateMovementVisual(float Value)
{
	if (bIsInteracting)
	{
		SetMoveDirection(Value);
	}
	else
	{
		ABaseDogPawn::UpdateMovementVisual(Value);
	}
}

void ADogPawn::GetAdditionalActorsToIgnore(TArray<AActor*>& Actors) const
{
	if (bIsInteracting && Box)
	{
		Actors.Add(Box);
	}
}
bool ADogPawn::CanMoveWithHead(const FVector& Delta)
{
	if (bIsInteracting && Box && bIsPushing && Box->GetIsBoxBlocked()) return false;

	if (bIsInteracting && Box && bIsPulling && Box->GetIsBoxBlocked()) return true;

	return ABaseDogPawn::CanMoveWithHead(Delta);
}
void ADogPawn::SetMoveDirection(float Value)
{
	if (!bIsInteracting || !Box)
	{
		if (bIsPulling || bIsPushing)
		{
			bIsPushing = false;
			bIsPulling = false;
			OnStopInteractVisual();
		}
		return;
	}

	bool WasPushing = bIsPushing;
	bool WasPulling = bIsPulling;

	float LookDirection = FMath::Sign(VisualContainer->GetForwardVector().X);
	float InputDirection = FMath::Sign(Value);

	float RelativeDirection = LookDirection * InputDirection;

	if (RelativeDirection > 0.0f)
	{
		if (!bIsPushing)
		{
			bIsPushing = true;
			bIsPulling = false;
			OnPushVisual();
		}		
	}
	else
	{
		if (!bIsPulling)
		{
			bIsPushing = false;
			bIsPulling = true;
			OnPullVisual();
		}		
	}

	if (bIsPushing != WasPushing || bIsPulling != WasPulling)
	{
		InteractMovementX();
	}
}


void ADogPawn::DoJump() 
{
	if (bIsInteracting) return;

	ABaseDogPawn::DoJump();
}

float ADogPawn::CalculateTargetY() const
{
	if (bIsInCover && StealthCover)
	{
		return StealthCover->GetCoverZoneY();
	}

	if (bIsInteracting && Box)
	{
		float BoxY = Box->GetBoxEdgeY();
		float DogY = CollisionHead->GetUnscaledBoxExtent().Y;

		return DogY + BoxY;
	}
	return ABaseDogPawn::CalculateTargetY();
}

void ADogPawn::CanInteractWithObjects()
{
	if (!CollisionBody || !CollisionHead) return;

	if (bIsCrouching || bIsJumping || bIsTakingItem || bIsInteracting) return;

	if (!bIsTakingItem) Bone = nullptr;
	if (!bIsInteracting) Box = nullptr;

	if (ScanForInteractableObject(InteractHitResult) && InteractHitResult.GetActor())
	{
		if (AInteractiveBox* FoundBox = Cast<AInteractiveBox>(InteractHitResult.GetActor()))
		{
			Box = FoundBox;
			return;
		}
		else if (AItemBone* FoundBone = Cast<AItemBone>(InteractHitResult.GetActor()))
		{
			Bone = FoundBone;
			return;
		}
	}
}
void ADogPawn::InteractPressed()
{
	if (Box)
	{
		if (GetActorLocation().Z > Box->GetBoxEdgeZ()) return;

		if (!PreCheckAlignmentSpace()) return;

		bIsInteracting = true;
		CollisionHead->IgnoreActorWhenMoving(Box, true);
		Box->StartFollow(this);

		InteractMovementX();
	}
}
void ADogPawn::InteractReleased()
{
	if (Box)
	{
		bIsInteracting = false;
		CollisionHead->IgnoreActorWhenMoving(Box, false);
		Box->StopFollow();
		OnStopInteractVisual();
	}
}
float ADogPawn::CalculateAlignmentDeltaX() const
{
	if (!Box || !CollisionHead) return 0.f;

	float DogDirection = FMath::Sign(VisualContainer->GetForwardVector().X);

	float BoxWall = (DogDirection > 0.f) ? Box->GetBoxLeftEdgeX() :
		Box->GetBoxRightEdgeX();

	return BoxWall - GetHeadEdgeX();
}
bool ADogPawn::PreCheckAlignmentSpace()
{
	if (!Box || !CollisionHead) return true;

	float DeltaX = CalculateAlignmentDeltaX();

	if (FMath::IsNearlyEqual(DeltaX, AlignmentTolerance)) return true;

	FHitResult HitResult;

	AddActorWorldOffset(FVector(DeltaX, 0.f, 0.f), true, &HitResult);

	if (HitResult.IsValidBlockingHit())
	{
		AActor* HitActor = HitResult.GetActor();
		if (HitActor && HitActor->IsA(AInteractiveBox::StaticClass()) == false)
		{
			float RealMovedDistance = DeltaX * HitResult.Time;
			AddActorWorldOffset(FVector(-RealMovedDistance, 0.f, 0.f), false);
			return false;
		}
		
	}
	AddActorWorldOffset(FVector(-DeltaX, 0.f, 0.f), false);
	return true;
}
void ADogPawn::InteractMovementX()
{
	if (!bIsInteracting || !Box || !CollisionHead) return;
	
	float DeltaX = CalculateAlignmentDeltaX();

	AddActorWorldOffset(FVector(DeltaX, 0.f, 0.f), false);

}
void ADogPawn::ForceStopMovement()
{
	VelocityX = 0.0f;
	SetMoveDirection(0.0f);
}

void ADogPawn::OnCrouchPressed()
{
	if (bIsInteracting) return;

	ABaseDogPawn::OnCrouchPressed();
}

float ADogPawn::GetHeadEdgeX() const
{
	if (!VisualContainer || !CollisionHead) return GetActorLocation().X;

	float Direction = FMath::Sign(VisualContainer->GetForwardVector().X);
	return CollisionHead->GetComponentLocation().X + (CollisionHead->GetScaledBoxExtent().X * Direction);
}

float ADogPawn::GetBodyEdgeY() const
{
	if (!CollisionBody) return GetActorLocation().Y;

	return CollisionBody->GetScaledBoxExtent().Y;
}

float ADogPawn::GetContainerForward() const
{
	if (!VisualContainer) return 1.f;
	return FMath::Sign(VisualContainer->GetForwardVector().X);
}

void ADogPawn::SetIsScared(bool NewIsScared)
{
	bIsScared = NewIsScared;

	APlayerController* PC = Cast<APlayerController>(GetController());
	if (PC)
	{
		if (NewIsScared)
		{
			DisableInput(PC);
		}
		else
		{
			EnableInput(PC);
		}
	}
}
bool ADogPawn::GetIsScared() const
{
	return bIsScared;
}
void ADogPawn::ScaredRun(float DeltaTime)
{
	if (!StopScaryEventZone || !bIsScared) return;

	float DogX = GetActorLocation().X;
	float SafeX = StopScaryEventZone->GetActorLocation().X;

	float Direction = (DogX > SafeX) ? -1.f : 1.f;

	float DeltaX = 0.f;

	if (Direction > 0)
	{
		OnLookRightVisual();
		DeltaX = ScarySpeed * DeltaTime;
	}
	else
	{
		OnLookLeftVisual();
		DeltaX = -ScarySpeed * DeltaTime;
	}
	
	float DistanceToSafe = FMath::Abs(SafeX - DogX);

	if (DistanceToSafe <= ScaryStopDistanceThreshold)
	{
		ForceStopMovement();
		DeltaX = 0.f;

		SetIsScared(false);
		return;
	}

	FVector DeltaLocation(DeltaX, 0.f, 0.f);
	AddActorWorldOffset(DeltaLocation, true);
}

void ADogPawn::HandleHouseIsLightingState(bool bIsLighting)
{
	bHouseIsLightingUp = bIsLighting;
}

void ADogPawn::HideInCover(float DeltaTime)
{
	if (CanHideInCover())
	{
		bIsInCover = true;			
	}
	else
	{
		bIsInCover = false;
	}
}
bool ADogPawn::CanHideInCover() const
{
	if (!bIsInCover)
	{
		return bHouseIsLightingUp && StealthCover && bWantToCrouch;
	}
	return StealthCover && bWantToCrouch;
}

void ADogPawn::SetCurrentCover(AStealthCover* NewCover)
{
	StealthCover = NewCover;	
}


// Called when the game starts or when spawned
void ADogPawn::BeginPlay()
{
	ABaseDogPawn::BeginPlay();

	CameraComp = Cast<USceneComponent>(GetDefaultSubobjectByName(TEXT("SpringArm")));

	if (HouseAlarmSystem)
	{
		HouseAlarmSystem->OnHouseStateChange.AddDynamic(this, &ADogPawn::HandleHouseIsLightingState);
	}
}

// Called every frame
void ADogPawn::Tick(float DeltaTime)
{
	ABaseDogPawn::Tick(DeltaTime);

	if (CameraComp)
	{
		FVector CameraLoc = CameraComp->GetComponentLocation();
		CameraLoc.Y = OriginalY;
		CameraComp->SetWorldLocation(CameraLoc);
	}
	
	HideInCover(DeltaTime);	

	if (bIsScared)
	{
		ScaredRun(DeltaTime);
	}
}

// Called to bind functionality to input
void ADogPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

